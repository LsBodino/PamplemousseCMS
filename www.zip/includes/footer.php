<center>
<style> .fixed-bottom {
  position: auto;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1030;
  margin-top: 50px;
}"</style>
<br><footer class="fixed-bottom">
<div class="container">
<b><?= $l_powered?> PamplemousseCMS | <?= $l_theme?>: <?= $theme?> | <?= $l_version?>: UP2 - 2021</b><br>
<a href="<?= $link?>/map"><?= $l_map?></a> | <a href="https://github.com/LsBodino/PamplemousseCMS" target="_blank">Github</a></div>
<br></footer></center>