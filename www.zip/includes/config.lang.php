<?php
include_once "includes/config.php";
if($lang == "en"){
    include_once "lang/en.php";
}
if($lang == "fr"){
    include_once "lang/fr.php";
}