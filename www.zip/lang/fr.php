<?php
// Pages d'erreurs
$l_error = "Erreur";
$l_badrequest = "Mauvaise requête.";
$l_accessd = "Accès refusé.";
$l_notfound = "Introuvable.";
$l_errorserver = "Erreur du serveur";
// Footer
$l_powered = "Propulsé par";
$l_theme = "Thème";
$l_version = "Version";
// Déconnexion
$l_logout = "Déconnexion";
// Plan
$l_map = "Plan";
$l_pages = "Pages";
// Accueil
$l_house = "Accueil";
$l_notregistered = "Hey, vous n'êtes pas inscrit !";
$l_notregistered2 = "Nous voyons que vous n'êtes pas inscrit sur";
$l_notregistered3 = "Inscrivez-vous pour partager vos contributions à la communauté";
$l_mostrecenta = "Articles les plus récents";
$l_read = "Lire";
// Espace
$l_myspace = "Mon Espace";
$l_spaceof = "Espace de";
$l_pseudo = "Pseudo";
$l_rank = "Grade";
$l_editspace = "Editer mon espace";
// Panel
$l_createarticle = "Créer un article";
$l_createpage = "Créer une page";
$l_configuration = "Configuration"
?>