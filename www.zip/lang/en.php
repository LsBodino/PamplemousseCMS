<?php
// Error page
$l_error = "Error";
$l_badrequest = "Bad Request.";
$l_accessd = "Access denied.";
$l_notfound = "Not found.";
$l_errorserver = "Error server.";
// Footer
$l_powered = "Powered by";
$l_theme = "Theme";
$l_version = "Version";
// Disconnect
$l_logout = "Disconnect";
// Map
$l_map = "Map";
$l_pages = "Pages";
// House
$l_house = "House";
$l_notregistered = "Hey, you’re not registered yet on !";
$l_notregistered2 = "I see you’re still not registered on";
$l_notregistered3 = "Sign up to share your contributions to the community";
$l_mostrecenta = "Most recent articles";
$l_read = "Read";
// Space
$l_myspace = "My space";
$l_spaceof = "Space of";
$l_pseudo = "Pseudo";
$l_rank = "Rank";
$l_editspace = "Edit my space";
// Panel
$l_createarticle = "Create a article";
$l_createpage = "Create a page";
$l_configuration = "Configuration"
?>