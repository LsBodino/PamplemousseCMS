<head>
<?php include 'includes/header.php';?>
<title><?= $title ?>: <?= $l_error ?> 500</title>
</head>
<body>
<center>
<h2><?= $l_error ?> 500</h2>
<?= $l_errorserver ?>
<br>
</center>
</body>
<?php include 'includes/footer.php';?>
