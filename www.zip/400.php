<head>
<?php include 'includes/header.php';?>
<title><?= $title ?>: <?= $l_error ?> 400</title>
</head>
<body>
<center>
<h2><?= $l_error ?> 400</h2>
<?= $l_badrequest ?>
<br>
</center>
</body>
<?php include 'includes/footer.php';?>
