<?php 
// Login to database (host, database name, database user, database password).
$db = new PDO('mysql:host=localhost;dbname=pcms;charset=utf8', 'root', '');
// Website name.
$title = "PamplemousseCMS";
// Website description.
$descr = "The Best Fruit of the World";
// Website Link.
$link = "http://127.0.0.1";
// Theme.
$theme = "plm-classic";
// Langage (fr = french, en = english).
$lang = "fr";
?>
