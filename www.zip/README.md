# PamplemousseCMS
PamplemousseCMS is a cms created by @LsBodino.

# Installation 
The configuration is done on the includes/config.php page and the database is in the Release page.

# Theme
Theme creation is not yet sufficiently developed.

Credits:
Bootstrap, jQuery, Bootflat, @LsBodino, Respond.js
