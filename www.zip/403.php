<head>
<?php include 'includes/header.php';?>
<title><?= $title ?>: <?= $l_error ?> 401 / 403</title>
</head>
<body>
<center>
<h2><?= $l_error ?> 401 / 403</h2>
<?= $l_accessd ?>
<br>
</center>
</body>
<?php include 'includes/footer.php';?>
