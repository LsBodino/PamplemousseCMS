<head>
<?php include 'includes/header.php';?>
<title><?= $title ?>: <?= $l_error ?> 404</title>
</head>
<body>
<center>
<h2><?= $l_error ?> 404</h2>
<?= $l_notfound ?>
</center>
<br>
</body>
<?php include 'includes/footer.php';?>
